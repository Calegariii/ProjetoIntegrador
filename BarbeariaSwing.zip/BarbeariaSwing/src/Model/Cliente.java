package Model;

public class Cliente extends Pessoa {

	private String endereco;
	private String cep;

	public Cliente(int id, String nome, char sexo, String dataNascimento, String telefone, String email, String rg,
			String endereco, String cep) {
		super(id, nome, sexo, dataNascimento, telefone, email, rg);
		this.endereco = endereco;
		this.cep = cep;
	}

	public Cliente(int id, String nome, String endereco, String cep) {
		super(id, nome);
		this.endereco = endereco;
		this.cep = cep;
	}

	public Cliente(int id, String nome, char sexo, String telefone, String endereco) {
		super(id, nome, sexo, null, telefone, null, null);
		this.endereco = endereco;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	@Override
	public String toString() {
		return "Cliente [id=" + id + ", nome=" + nome + ", sexo=" + sexo + ", dataNascimento=" + dataNascimento
				+ ", telefone=" + telefone + ", email=" + email + ", rg=" + rg + ", endereco=" + endereco + ", cep="
				+ cep + "]";
	}
}
